package br.edu.unifcv.faculdade.model;

public interface Calculadora {
	
	void Calcular(Integer valor1, Integer valor2);
	void Resultado();

}
